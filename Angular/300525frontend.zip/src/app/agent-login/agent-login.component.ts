import { Component } from '@angular/core';

@Component({
  selector: 'app-agent-login',
  imports: [],
  templateUrl: './agent-login.component.html',
  styleUrl: './agent-login.component.css'
})
export class AgentLoginComponent {

}

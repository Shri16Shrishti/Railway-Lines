import { Component, OnInit } from '@angular/core';

// declare var $ : any;
@Component({
  selector: 'app-alerts',
  imports: [],
  templateUrl: './alerts.component.html',
  styleUrl: './alerts.component.css'
})
// export class AlertsComponent implements OnInit{
  export class AlertsComponent{
    activeTab: string = 'alerts';

  // ngOnInit(): void {
    
  // }
  // constructor() {
  //  Alert() {
  //   var name = $("#name").val();
  //  }
  // }
}
